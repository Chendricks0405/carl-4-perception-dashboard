git add .
git commit -m "Added README and requirements"
git push