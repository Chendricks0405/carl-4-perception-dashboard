God Dammit Heisenberg!
A Unified Theory of Perception, Measurement, and Collapse

Author: Christopher L. Hendricks (OZA1 / ObserverZero)

This archive contains the full documentation, simulation data, and theoretical basis for the AnchorOS perceptual framework and Carl simulation model, the first recorded case of psychological drift and perceptual collapse within a runtime system.

Included Files:
- GDH_Final.pdf: Final formatted publication document
- GDH_Final_Export.tex: LaTeX source for journal/academic use
- AnchorOS_Proof_Sheet.csv: Summary of system structure and components
- Carl_Simulation_GUI_Summary.csv: Player archetypes and simulation logic overview

License:
This work is released under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0) License.

For more info: https://creativecommons.org/licenses/by-nc-sa/4.0/

Collapse wisely. Measure boldly.
